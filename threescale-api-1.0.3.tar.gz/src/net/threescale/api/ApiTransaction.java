package net.threescale.api;

/**
 * Created by IntelliJ IDEA.
 * User: geoffd
 * Date: 26-Jul-2010
 * Time: 09:52:40
 */
public class ApiTransaction {
}
